
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <conio.h>
#include <windows.h>
#include <time.h>

#ifndef ENABLE_VIRTUAL_TERMINAL_PROCESSING
#define ENABLE_VIRTUAL_TERMINAL_PROCESSING 0x0004
#endif


extern int coin_count;
extern int cat_lives;
extern int offsetX;
extern int shield;
extern int score_count;
extern int mapindex;
extern int game_over;
extern int sizemario;
extern int retry_count;
extern int fail_count;
extern int shield_delete;
extern int changesizemario;
#ifndef MYFUNCS_H
#define MYFUNCS_H
void moveCharacter(int *i, int *j, char board[][64], int newI, int newJ);
void moveCharacter2(int *i, int *j, char board[][64], int newJ, int *i2, int *j2);
void enableANSI();
void moveCursor(int x, int y);
void Yellow();

void Green();

void White();

void Red();

void Cyan();

void drawfirstlevel(int select, int retry);
int firstlevelPassed(int *pusercoin, int *puserscore, int *puserstat1, int *puserstat2);
void drawsecondlevel(int select, int retry);
int secondlevelPassed(int *pusercoin, int *puserscore, int *puserstat1, int *puserstat2);
void drawfailedlevel(int select);
int levelfailed();

void printTimeRemaining();

void coin_block(char map_1[][64], int char_i, int char_j, int map, int retry);

void destructible_block();

void printBoard(char board[][64], int cory);

void moveMush(char map_2[][64], int char_i, int char_j, int flag, int random);

int moveBlock5(char board[][64], int *block5_i, int *block5_j, DWORD *lastUpdate, int delay, int *catY, int *catX, int *direction);

void updateBlockStatus(char board[][64], DWORD *lastUpdate, int delay, int *toggle, int emoji1_i, int emoji1_j, int emoji2_i, int emoji2_j, int *i, int *j);
// maps functions
int map2(int *pusercoin, int *puserscore, int *puserstat1, int *puserstat2);

int map1(int *pusercoin, int *puserscore, int *puserstat1, int *puserstat2);
#endif